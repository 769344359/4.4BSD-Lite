/*
 * $Source: /mit/kerberos/src/lib/des/RCS/debug_decl.c,v $
 * $Author: steiner $
 *
 * Copyright 1988 by the Massachusetts Institute of Technology.
 *
 * For copying and distribution information, please see the file
 * <mit-copyright.h>.
 *
 * Declaration of debugging flag.
 */

#ifndef	lint
static char rcsid_debug_decl_c[] =
"$Header: debug_decl.c,v 4.2 88/02/24 14:20:36 steiner Exp $";
#endif	lint

#include <mit-copyright.h>
int	des_debug	= 0;
