ccflags="$ccflags -J -DBADSWITCH"
