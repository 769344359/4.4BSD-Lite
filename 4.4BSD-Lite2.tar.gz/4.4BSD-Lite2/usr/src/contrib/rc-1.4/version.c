const char id[] = "@(#)rc version 1.4-BSD, 4/30/93.";
