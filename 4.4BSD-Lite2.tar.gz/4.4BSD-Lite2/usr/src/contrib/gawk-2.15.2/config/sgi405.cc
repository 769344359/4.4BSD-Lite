SGI Personal Iris (Sys V derived) (this works with cc)
BLKSIZE_MISSING	1 
STDC_HEADERS	1 
CHAR_UNSIGNED   1
MAKE_CC
MAKE_SGI
