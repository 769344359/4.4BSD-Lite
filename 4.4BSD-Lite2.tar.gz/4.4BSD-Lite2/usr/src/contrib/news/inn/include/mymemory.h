/*  $Revision: 1.2 $
**
**  Minimal <memory.h> file for systems without one.
*/

extern POINTER	memchr();
extern POINTER	memcpy();
extern POINTER	memset();
