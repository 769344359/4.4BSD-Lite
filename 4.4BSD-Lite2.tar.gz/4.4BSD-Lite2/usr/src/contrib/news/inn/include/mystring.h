/*  $Revision: 1.3 $
**
**  Minimal <string.h> file for systems without one.
*/

extern char	*strcat();
extern char	*strchr();
extern char	*strcpy();
extern char	*strncat();
extern char	*strncpy();
extern char	*strpbrk();
extern char	*strrchr();
extern char	*strstr();
extern char	*strtok();
extern int	strcasecmp();
extern int	strncasecmp();
extern int	strcmp();
extern int	strcspn();
extern int	strlen();
extern int	strncmp();
extern int	strspn();
